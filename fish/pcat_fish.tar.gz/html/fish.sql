create database if not exists `fish` default character set utf8;
use `fish`;

drop table if exists `user`;
create table `user`(
    `qq` varchar(255) default null,
    `pwd` varchar(255) default null 
) engine=InnoDB default charset=utf8;

lock tables `user` write;
insert into `user` values('10000','10000');
insert into `user` values('10068','10068');
unlock tables;

create user 'fish'@'localhost' identified by 'fish';
grant select,insert on fish.user to fish;
grant file on *.* to 'fish'@'localhost';
flush privileges;