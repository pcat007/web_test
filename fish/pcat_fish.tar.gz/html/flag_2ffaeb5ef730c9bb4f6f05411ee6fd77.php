<?php
$flag="hbctf{fuck_phishing}";