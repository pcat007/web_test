<?php
error_reporting(0);
require_once('db.php');
?>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
<head>
    <title>search</title>
</head>
<body>
    <form method="post">
       <input type="text" name="qq"  placeholder="qq number"><input type="submit" value="search">
    </form>
</body>
</html>

<?php
if(!isset($_POST['qq'])){
    die('');
}else{
    $qq=$_POST['qq'];
    /*
    not waf.
    */
    $con=mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_DATABASE);
    if(!$con){
        die('wtf...please contact the admin.');
    }
    $sql="select pwd from user where qq ='".$qq."'";
    // echo 'sql> '.$sql.'<br/>';
    // echo '<br/>';
    $result=mysqli_query($con,$sql);
    $rowcount=mysqli_num_rows($result);
    if($rowcount>0){
        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
        echo $row['pwd'];
    }else{
        echo 'No result.';
    }
    mysqli_close($con);
}
?>