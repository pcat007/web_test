<?php
define('DB_HOST','localhost');
define('DB_USER','fish');
define('DB_PASS','fish');
define('DB_DATABASE','fish');
?>