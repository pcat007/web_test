#!/bin/bash
ldconfig

/etc/init.d/apache2 restart
/etc/init.d/mysql restart
/usr/local/bin/ssserver -c /etc/shadowsocks-libev/config.json -d start
/usr/bin/tail -f /dev/null
