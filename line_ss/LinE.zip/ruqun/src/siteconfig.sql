UPDATE `wordpress`.`wp_options` SET  `option_value` = 'http://114.215.113.20' WHERE (`option_name` = 'siteurl');
UPDATE `wordpress`.`wp_options` SET `option_value` = 'http://114.215.113.20' WHERE (`option_name` = 'home');
