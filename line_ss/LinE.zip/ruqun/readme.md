# FLAG
**flag{6438c669e0d0de98e6929c2cc0fac474}**

--------

# 部署
1. 解压
    ```bash
    unzip ruqun.zip
    cd ruqun
    ```
2. 修改站点访问地址，修改**src/siteconfig.sql**中的**option_value**为实际访问地址，如果Web端口不为80请添加端口号
    ```sql
    UPDATE `wordpress`.`wp_options` SET  `option_value` = 'http://114.215.113.20' WHERE (`option_name` = 'siteurl');
    /** or **/
    UPDATE `wordpress`.`wp_options` SET `option_value` = 'http://114.215.113.20:8080' WHERE (`option_name` = 'siteurl');
    ```
3. 使用Docker构建镜像，tag可以自行根据需求设置
    ```bash
    docker build . --tag=ruqun
    ```
4. 运行容器，需要对外映射**80**及**9999**端口，如果Web端口不为80请自行修改，但请注意要与第2步SQL中的端口一致
    ```bash
    docker run -dit -p 80:80 -p 9999:9999 ruqun
    ```

--------

# 解题思路
1. 阅读搭建shadowsocks的过程，发现文章中泄漏了shadowsocks的连接端口**9999**和密码**b6a1611cea98b187dd05be6c2a91b6fb**
2. 首页中还有一个加密文章
3. 使用SS客户端连接上这个SS，挂全局SS代理对127.0.0.1(即SS服务端本地)进行端口扫描，发现开放3306端口，爆破之后得到mysql账号**wordpress**及密码**wordpress**
4. 使用navicat+全局代理(Proxifier)连接到数据库，在数据库中查到加密文章的密码是**76871585285ea5cf4869f1941d84e691**，查看文章之后得到后面密码的算法
5. 使用navicat+本地代理(Proxifier)连接到数据库，发现有**flag**库，库中有**glaf**表，其中有两条数据
6. 将BLOB的数据拉下来发现是N多的16进制，根据数据可以知道这实际上是文件的16进制数据，只不过每16字节加了换行符(\r\n)，干掉换行符之后直接写入原始16进制即可得到文件
7. id=1的数据是一个txt文件，是一个提示，该提示表明之前使用过的某个密码可能会重复使用，此处有点脑洞
8. id=2的数据是一个7z压缩包，文件类型可以从文件头得知，打开发现是个加密文件，密码可以从wordpress的加密文章中得到密码算法，传入参数**7z**得到解压密码**7b363cd94672963dcb91ee9bc6ec3fdb**，解压之后得到两个mp3文件
9. 1.MP3的BBB00位置写了一个提示表示下面是个PNG文件，但是文件头不正确，需要修复
    * 修复BBB10h到BBB14h为PNG头(89504E47)
    * 修复BBB1Ch到BBB1Fh为PNG的常用数据块格式IHDR(49484452)
    * 修复完成之后将BBB10h至结尾抠出来另存为hades.png
    * 打开hades.png发现是韩剧幽灵中hades的Logo，此处为第一个提示，表示本题与幽灵有关
10. 2.MP3是第二个与幽灵有关的提示(主题曲)，根据韩剧幽灵中剧情可知道哈迪斯使用的隐写工具为**OpenStego**，相关资料可在[http://www.freebuf.com/articles/database/99504.html](http://www.freebuf.com/articles/database/99504.html)看到
11. 用OpenStego打开hades.png进行解密，密码根据第7步的提示，尝试之前获得的所有密码，发现密码就是shadowsocks的连接密码**b6a1611cea98b187dd05be6c2a91b6fb**
12. 解密hades.png之后得到flag.txt，里面为最终flag

